# [DS-Agent] v2.0.0-Ultimate
import json

class BrowserTools:
    def __init__(self, cdp):
        self.cdp = cdp

    async def eval_js(self, js):
        res = await self.cdp.send("Runtime.evaluate", {
            "expression": js, "returnByValue": True, "awaitPromise": True
        })
        if "exceptionDetails" in res.get("result", {}):
            return f"❌ JS 报错: {json.dumps(res['result']['exceptionDetails'])}"
        val = res.get("result", {}).get("result", {}).get("value")
        return f"✅ JS 返回值: {val}"