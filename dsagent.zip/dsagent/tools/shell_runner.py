# [DS-Agent] v2.0.0-Ultimate
import asyncio

class ShellRunner:
    async def run(self, cmd):
        print(f"💻 [Shell] 执行: {cmd}")
        # 使用 create_subprocess_shell 执行命令
        process = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        out = stdout.decode() if stdout else stderr.decode()
        return f"✅ Shell 结果:\n{out}"