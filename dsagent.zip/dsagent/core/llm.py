import httpx

class LLM:
    def __init__(self, config):
        self.api_key = config["api_key"]
        self.base_url = config["base_url"]
        self.model = config["model"]
        self.temp = config.get("temperature", 0.2)

    async def chat(self, messages):
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": self.model, "messages": messages, "temperature": self.temp},
                timeout=90.0
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]