# [DS-Agent] v2.1.0-Ultimate
import re
import json
import asyncio
from tools.browser_tools import BrowserTools
from tools.shell_runner import ShellRunner

class Parser:
    def __init__(self, cdp):
        self.browser = BrowserTools(cdp)
        self.shell = ShellRunner()

    async def execute(self, text):
        results = []
        
        # 1. 提取并执行 Shell (极其宽容的匹配，忽略大小写)
        shell_pattern = r'<shell>\s*(.*?)\s*</shell>'
        for cmd in re.findall(shell_pattern, text, re.DOTALL | re.IGNORECASE):
            clean_cmd = cmd.replace("//!", "").strip()
            results.append(await self.shell.run(clean_cmd))
            
        # 2. 提取并执行 JS (极其宽容的匹配)
        js_pattern = r'<javascript>\s*(.*?)\s*</javascript>'
        for js in re.findall(js_pattern, text, re.DOTALL | re.IGNORECASE):
            res_text = await self.browser.eval_js(js)
            # 防爆截断
            if len(res_text) > 3000:
                res_text = res_text[:3000] + "\n...[⚠️数据过长已截断，请优化你的 JS 代码，只返回核心字段]"
            results.append(res_text)
            
        # 3. 提取并执行 CDP (极其宽容的匹配)
        cdp_pattern = r'<cdp>\s*(.*?)\s*</cdp>'
        matches = re.findall(cdp_pattern, text, re.DOTALL | re.IGNORECASE)
        
        # 兜底：如果 AI 忘记写闭合标签，但写了 <cdp> 和 {
        if not matches and "<cdp>" in text.lower():
            matches = [text.lower().split("<cdp>")[-1].split("</")[0]]

        for cmd in matches:
            try:
                clean_cmd = re.sub(r'^//\s*CDP:\s*', '', cmd.strip())
                payload = json.loads(clean_cmd)
                method = payload.get("method")
                
                res = await self.browser.cdp.send(method, payload.get("params", {}))
                
                # 特殊处理 Runtime.evaluate，直接提取具体的值，并防爆截断
                if method == "Runtime.evaluate" and "result" in res:
                    val = str(res.get("result", {}).get("result", {}).get("value", ""))
                    if len(val) > 3000:
                        val = val[:3000] + "\n...[⚠️数据过长已截断，请写 JS 提取核心字段]"
                    results.append(f"✅ CDP (JS) 返回值:\n{val}")
                else:
                    results.append(f"✅ CDP 执行成功: {json.dumps(res)[:1000]}")
            except Exception as e:
                results.append(f"❌ CDP 解析失败: {e}")

        return "\n\n".join(results) if results else "Observation: 没有检测到可执行指令。请使用 <shell>, <javascript>, 或 <cdp> 标签包裹你的代码。"