import json
import os

class Memory:
    def __init__(self, filepath):
        self.filepath = filepath

    def load(self, default_prompt):
        if os.path.exists(self.filepath):
            with open(self.filepath, "r", encoding="utf-8") as f:
                history = json.load(f)
                history[0] = {"role": "system", "content": default_prompt}
                return history
        return [{"role": "system", "content": default_prompt}]

    def save(self, history):
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)