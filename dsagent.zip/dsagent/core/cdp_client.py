# [DS-Agent] v2.0.0-Ultimate
import json
import asyncio
import websockets
import datetime

class CDPClient:
    def __init__(self, ws_url):
        self.ws_url = ws_url
        self.ws = None
        self.msg_id = 0
        self.pending = {}
        self.is_connected = False

    async def connect(self):
        while True:
            try:
                self.ws = await websockets.connect(self.ws_url, max_size=50*1024*1024)
                self.is_connected = True
                print("✅ CDP 通道已连接")
                asyncio.create_task(self._listen())
                break
            except Exception as e:
                print(f"❌ CDP 连接失败，5秒后重试: {e}")
                await asyncio.sleep(5)

    async def _listen(self):
        try:
            async for message in self.ws:
                data = json.loads(message)
                if "id" in data and data["id"] in self.pending:
                    future = self.pending.pop(data["id"])
                    if not future.done():
                        future.set_result(data)
                
                # 拦截网络请求，过滤无用资源，只记录 API
                if data.get("method") == "Network.requestWillBeSent":
                    req = data["params"]["request"]
                    url = req["url"]
                    if any(key in url for key in ["/api/", "/x/", "login", "sign", "auth"]): 
                        log_line = f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {req['method']} {url}"
                        print(f"🌐 [捕获API] {log_line}")
                        with open("/sdcard/dsagent/logs/network.log", "a", encoding="utf-8") as f:
                            f.write(log_line + "\n")
        except websockets.ConnectionClosed:
            print("⚠️ CDP 连接断开，准备重连...")
            self.is_connected = False
            await self.connect()

    async def send(self, method, params=None):
        if not self.is_connected:
            return {"error": "WebSocket not connected"}
        
        self.msg_id += 1
        req_id = self.msg_id
        msg = {"id": req_id, "method": method, "params": params or {}}
        
        short_params = str(params)[:50] + "..." if params else "{}"
        print(f"📤 [CDP] {method} | {short_params}")
        
        future = asyncio.get_event_loop().create_future()
        self.pending[req_id] = future
        await self.ws.send(json.dumps(msg))
        
        try:
            return await asyncio.wait_for(future, timeout=15.0)
        except asyncio.TimeoutError:
            return {"error": "Timeout"}