
## 弹幕发送接口审计 (BV1tZxj6ZEVa)
- 登录态: 无 SESSDATA (未登录)
- 弹幕输入框 .bpx-player-dm-input 存在但默认隐藏 (vis:false)
- 发送区容器 .bpx-player-sending-area 可见
- 强制显示输入框+填入+点击发送按钮后:
  - 未产生 /x/v2/dm/post 请求
  - 仅产生: data.bilibili.com 埋点 + x/player/online/total 在线人数
- 结论: 前端在未登录时于发送逻辑入口直接 return，未构造请求
- 接口路径(标准): POST https://api.bilibili.com/x/v2/dm/post
  参数: type=1, oid=cid, msg, bvid, progress(ms), mode, fontsize, color, pool, csrf(bili_jct)
