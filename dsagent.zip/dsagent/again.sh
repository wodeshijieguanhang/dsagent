#!/bin/bash
cd /sdcard/dsagent
echo "♻️ 检查并重启 ADB..."
adb connect 192.168.3.52:35479 > /dev/null 2>&1
adb forward tcp:9222 localabstract:chrome_devtools_remote

# 启动 Python
python main.py