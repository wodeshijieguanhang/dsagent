# 补充武器库
- 如果需要查找特定加密逻辑，优先使用 Debugger.searchInContent 搜索关键字。
- 如果页面存在 iframe 导致无法获取 DOM，请遍历所有 frame 的上下文。
- 遇到反调试（如无限 debugger），请重写 Function.prototype.constructor。