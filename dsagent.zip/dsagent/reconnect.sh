#!/bin/bash
echo "======================================"
echo "🔄 DS-Agent 无线调试一键重连工具"
echo "======================================"

# 获取手机当前的 IP 地址（假设前三位一致，自动获取第四位，或者让用户输入）
DEFAULT_IP=$(ifconfig wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
if [ -z "$DEFAULT_IP" ]; then
    DEFAULT_IP="192.168.3.46" # 如果获取失败，用你截图里的 IP
fi

echo "📱 当前设备局域网 IP 检测为: $DEFAULT_IP"
read -p "1️⃣ 请输入【WLAN 配对码】(直接回车跳过配对): " PAIR_CODE
if [ -n "$PAIR_CODE" ]; then
    read -p "2️⃣ 请输入【配对端口】(弹窗里的 IP 地址和端口): " PAIR_PORT
    echo "🔗 正在尝试配对..."
    adb pair $DEFAULT_IP:$PAIR_PORT $PAIR_CODE
    
    if [ $? -ne 0 ]; then
        echo "❌ 配对失败，请检查配对码和端口是否正确！"
        exit 1
    fi
    echo "✅ 配对成功！"
else
    echo "⏭️ 跳过配对，直接连接..."
fi

read -p "3️⃣ 请输入【连接端口】(背景页面的 IP 地址和端口): " CONNECT_PORT
echo "🔌 正在连接..."
adb connect $DEFAULT_IP:$CONNECT_PORT

# 验证是否连接成功
DEVICES=$(adb devices | grep -v "List" | grep "device")
if [ -z "$DEVICES" ]; then
    echo "❌ 连接失败，请确认端口是否正确，或者无线调试是否开启。"
    exit 1
fi
echo "✅ ADB 连接成功！"

echo "🌐 正在建立 CDP 端口映射..."
adb forward tcp:9222 localabstract:chrome_devtools_remote

echo "🎉 环境准备完毕！你可以运行 ./again.sh 启动 Agent 了。"
